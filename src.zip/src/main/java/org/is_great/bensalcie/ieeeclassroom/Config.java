package org.is_great.bensalcie.ieeeclassroom;

public class Config {
    private Config() {
    }

    public static final String YOUTUBE_API_KEY = "AIzaSyDiZUbW_4W40AtSUajBw72ctMmbaRIoPtc";
}
