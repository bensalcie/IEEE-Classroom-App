package org.is_great.bensalcie.ieeeclassroom;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class ClassActivity extends YouTubeBaseActivity {

    private WebView myWeb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String video=getIntent().getStringExtra("video");

        myWeb=findViewById(R.id.detailVideo);
        myWeb.getSettings().setJavaScriptEnabled(true);
        myWeb.setWebChromeClient(new WebChromeClient());
        myWeb.loadData("<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/"+video+"\" frameborder=\"0\" allowfullscreen></iframe>","text/html","utf-8");
    }


}
