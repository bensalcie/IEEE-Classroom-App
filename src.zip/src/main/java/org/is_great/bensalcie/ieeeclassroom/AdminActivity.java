package org.is_great.bensalcie.ieeeclassroom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminActivity extends AppCompatActivity {
    private DatabaseReference mAdminDatabase,tutsDatabase;
    private Button btnAdmin;
    private EditText etTitle,etContent,etTutorial;
    private RadioButton btn_tutorial,btn_notification;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        mAdminDatabase = FirebaseDatabase.getInstance().getReference().child("MadCNotifications");
        tutsDatabase = FirebaseDatabase.getInstance().getReference().child("MadCTutorials");

        btnAdmin = findViewById(R.id.admin_btn_sendNotification);
        etTitle = findViewById(R.id.admin_title);
        etContent = findViewById(R.id.admin_content);
        btn_tutorial = findViewById(R.id.rb_tutorial);
        btn_notification=findViewById(R.id.rb_notification);
        etTutorial=findViewById(R.id.admin_url);

            btnAdmin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String title = etTitle.getText().toString().trim();
                    String content = etContent.getText().toString().trim();

                    if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(content)) {
                        if (btn_notification.isChecked()) {

                            postData(title, content);
                        }else if (btn_tutorial.isChecked())
                        {


                            DatabaseReference newTutoarial=tutsDatabase.push();
                            String tutorial=etTutorial.getText().toString().trim();
                            if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(content) && !TextUtils.isEmpty(tutorial)) {
                                newTutoarial.child("title").setValue(title);
                                newTutoarial.child("content").setValue(content);
                                newTutoarial.child("tutorial").setValue(tutorial);
                                Toast.makeText(AdminActivity.this, "Done Uploading tutorial...", Toast.LENGTH_SHORT).show();
                            }else {
                                Toast.makeText(AdminActivity.this, "Check inputs...", Toast.LENGTH_SHORT).show();


                            }
                        }
                        //eWEF1Zrmdow

                    } else {
                        Toast.makeText(AdminActivity.this, "Check your inputs...", Toast.LENGTH_SHORT).show();
                    }
                }
            });







    }
    private void postData(String t,String c) {
        DatabaseReference newNotification=mAdminDatabase.push();
        newNotification.child("title").setValue(t);
        newNotification.child("content").setValue(c);
        Toast.makeText(this, "Done Sending Notification...", Toast.LENGTH_SHORT).show();
    }


}
