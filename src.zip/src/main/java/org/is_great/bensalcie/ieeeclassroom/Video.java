package org.is_great.bensalcie.ieeeclassroom;

public class Video {
    public Video()
    {
    }
    private String title,content,tutorial;

    public Video(String title, String content, String tutorial) {
        this.title = title;
        this.content = content;
        this.tutorial = tutorial;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTutorial() {
        return tutorial;
    }

    public void setTutorial(String tutorial) {
        this.tutorial = tutorial;
    }
}
