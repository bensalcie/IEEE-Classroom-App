package org.is_great.bensalcie.ieeeclassroom;

public class Posts {
    private String post;
    private String photo;
    private String _image;
    private String name;

    public Posts(String _image, String name) {
        this._image = _image;
        this.name = name;
    }

    public String get_image() {
        return _image;
    }

    public void set_image(String _image) {
        this._image = _image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Posts(String post) {
        this.post = post;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public Posts()
    {

    }
}
