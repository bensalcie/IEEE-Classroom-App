package org.is_great.bensalcie.ieeeclassroom;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private FirebaseAuth mAuth;
    private DatabaseReference mAccountDatabase;


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    getSupportActionBar().setTitle("Fun Page");

                    HomeFragment homeFragment=new HomeFragment();
                    FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
                    ft.setCustomAnimations(R.anim.enter_from_down,R.anim.exit_to_left);
                    ft.replace(R.id.container,homeFragment);
                    ft.commit();

                    return true;
                case R.id.navigation_dashboard:
                    getSupportActionBar().setTitle("Classroom");

                    ClassroomFragment classroomFragment=new ClassroomFragment();
                    FragmentTransaction ft1=getSupportFragmentManager().beginTransaction();
                    ft1.setCustomAnimations(R.anim.enter_from_down,R.anim.exit_to_left);
                    ft1.replace(R.id.container,classroomFragment);
                    ft1.commit();
                    return true;
                case R.id.navigation_notifications:
                    getSupportActionBar().setTitle("Notifications");

                    NotificationFragment notificationFragment=new NotificationFragment();
                    FragmentTransaction ft2=getSupportFragmentManager().beginTransaction();
                    ft2.setCustomAnimations(R.anim.enter_from_down,R.anim.exit_to_left);
                    ft2.replace(R.id.container,notificationFragment);
                    ft2.commit();
                    return true;
            }
            return false; }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
mAuth=FirebaseAuth.getInstance();
        mAccountDatabase= FirebaseDatabase.getInstance().getReference().child("IEEEmadc_accounts");

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        getSupportActionBar().setTitle("IEEE Classroom");

       // getSupportActionBar().setTitle("      IEEE madC Classroom");
        HomeFragment homeFragment=new HomeFragment();
        FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
        ft.setCustomAnimations(R.anim.enter_from_down,R.anim.enter_from_down);
        ft.replace(R.id.container,homeFragment);
        ft.commit();
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        if (currentUser==null)

        {
            sendToLogin();

        }else{
             String userId=mAuth.getCurrentUser().getUid();

            checkProfile(userId);
        }
    }

    private void checkProfile(String userId) {
        DatabaseReference userDatabase=mAccountDatabase.child(userId);
        userDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("name").getValue()!=null)
                {

                }else {

                    sendToAccount();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }

    private void sendToAccount() {
        startActivity(new Intent(MainActivity.this,AccountActivity.class));
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        String adminUser=mAuth.getCurrentUser().getEmail().toString();

        if (adminUser.equals("bensalcie@gmail.com"))
        {
            getMenuInflater().inflate(R.menu.admin_menu_main,menu);

        }else {
            getMenuInflater().inflate(R.menu.menu_main, menu);

        }
            return super.onCreateOptionsMenu(menu);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        String adminUser=mAuth.getCurrentUser().getEmail().toString();


        int A=item.getItemId();
        if (A==R.id.action_account)
        {
startActivity(new Intent(MainActivity.this,AccountActivity.class));

        }else if (A==R.id.action_logout)
        {

           mAuth.signOut();
           sendToLogin();
        }

        if(adminUser.equals("bensalcie@gmail.com"))
        {
            if (A==R.id.action_admin)
            {
                Toast.makeText(this, "Admin Posting...", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this,AdminActivity.class));
                finish();
            }
            /*else if(A==R.id.action_video)
            {
                startActivity(new Intent(MainActivity.this,ClassActivity.class));
            }*/
        }
        return super.onOptionsItemSelected(item);
    }

    private void sendToLogin() {
        startActivity(new Intent(MainActivity.this,LoginActivity.class));
        finish();
    }
}
