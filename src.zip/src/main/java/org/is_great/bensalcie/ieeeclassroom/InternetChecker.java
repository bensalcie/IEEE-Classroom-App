package org.is_great.bensalcie.ieeeclassroom;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class InternetChecker {
    public boolean isInternetConnection(Context ctx)
    {
        ConnectivityManager manager=(ConnectivityManager)ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager!=null)
        {
            NetworkInfo info[] =manager.getAllNetworkInfo();
            if (info!=null)
            {
                for (int i=0;i<info.length;i++)
                {
                    if (info[i].getState()==NetworkInfo.State.CONNECTING)
                        return true;


                }
            }
        }
        return false;
    }
}
