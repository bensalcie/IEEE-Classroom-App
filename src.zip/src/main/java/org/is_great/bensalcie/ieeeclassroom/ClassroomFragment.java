package org.is_great.bensalcie.ieeeclassroom;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class ClassroomFragment extends Fragment   {

    View v;
    private RecyclerView videoList;
    private static final int RECOVERY_REQUEST = 1;
    private DatabaseReference mVideoDatabase;

    //private String YouTubeKey = "AIzaSyDiZUbW_4W40AtSUajBw72ctMmbaRIoPtc";
    public ClassroomFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        v= inflater.inflate(R.layout.fragment_classroom, container, false);
        //mVideoDatabase=FirebaseDatabase.getInstance().getReference().child("MadCTutorials");
        mVideoDatabase = FirebaseDatabase.getInstance().getReference().child("MadCTutorials");
        videoList=v.findViewById(R.id.videoList);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getContext());
       // ((LinearLayoutManager) layoutManager).setReverseLayout(true);
        videoList.setLayoutManager(layoutManager);

        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<Video,VideoViewHolder> recyclerAdapter=new FirebaseRecyclerAdapter<Video, VideoViewHolder>(Video.class,R.layout.video_view,VideoViewHolder.class,mVideoDatabase) {
            @Override
            protected void populateViewHolder(VideoViewHolder viewHolder, final Video model, int position) {
                viewHolder.setItems(model.getTitle(),model.getTutorial());
               /* viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(getActivity().getApplicationContext(),ClassActivity.class)
                                .putExtra("video",model.getTutorial()));

                    }
                });
*/
            }
        };
        videoList.setAdapter(recyclerAdapter);
    }
    public static class VideoViewHolder extends RecyclerView.ViewHolder{

        View mView;
        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            mView=itemView;
        }
        public void setItems(String title,String tutorial)
        {

            TextView tvTitle =mView.findViewById(R.id.tvWebTitle);
            WebView myWeb=mView.findViewById(R.id.youtubeWeb);
            myWeb.getSettings().setJavaScriptEnabled(true);
            myWeb.setWebChromeClient(new WebChromeClient());
            tvTitle.setText(title);
            myWeb.loadData("<iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube.com/embed/"+tutorial+"\" frameborder=\"0\" allowfullscreen></iframe>","text/html","utf-8");

        }



        }


}
