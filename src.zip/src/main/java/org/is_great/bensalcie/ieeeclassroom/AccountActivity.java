package org.is_great.bensalcie.ieeeclassroom;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import de.hdodenhof.circleimageview.CircleImageView;

public class AccountActivity extends AppCompatActivity {

    private static final int GALLERY_REQUEST_CODE = 5678;
    private EditText etName,etPhone,etStatus;
    private CircleImageView profile_pic;
    private Button btnUpdateProfile;
    private Uri imageUri=null;
    private FirebaseAuth mAuth;
    private DatabaseReference mAccountDatabase;
    private StorageReference mUsersStorage;
    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        getSupportActionBar().hide();
        mAuth=FirebaseAuth.getInstance();
pd=new ProgressDialog(this);
pd.setTitle("Just a moment");
pd.setMessage("Updating account...");


mAccountDatabase= FirebaseDatabase.getInstance().getReference().child("IEEEmadc_accounts");
mUsersStorage= FirebaseStorage.getInstance().getReference().child("IEEEmadc_photos");

        etName=findViewById(R.id.etName);
        etPhone=findViewById(R.id.etPhone);
        etStatus=findViewById(R.id.etStatus);

        profile_pic=findViewById(R.id.prof_pic);
        //attatchUserData(mAccountDatabase);

        profile_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent=new Intent(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,GALLERY_REQUEST_CODE);
            }
        });
        btnUpdateProfile=findViewById(R.id.btnUpdateAccount);
        btnUpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pd.show();
                String name=etName.getText().toString().trim();
                String phone=etPhone.getText().toString().trim();
                String status=etStatus.getText().toString().trim();

                if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(phone) && !TextUtils.isEmpty(status))
                {

                    if (imageUri!=null)
                    {


                      createAccount(name,phone,imageUri,mAuth.getCurrentUser().getEmail(),status);

                    }else {
                        pd.dismiss();
                        Toast.makeText(AccountActivity.this, "Please tap the avatar to choose profile picture...", Toast.LENGTH_SHORT).show();
                    }

                }else {
                    pd.dismiss();
                    Toast.makeText(AccountActivity.this, "Something went wrong..." +
                            "", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    private void createAccount(final String name, final String phone, Uri imageUri, final String email ,final String status) {
        final String userId=mAuth.getCurrentUser().getUid();

        StorageReference userImageStorage=mUsersStorage.child("IEEEmadc_user_profiles").child(userId+".jpg");
        userImageStorage.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                if (task.isSuccessful())
                {

                    Uri downloadUri=task.getResult().getDownloadUrl();
                    DatabaseReference userDatabase=mAccountDatabase.child(userId);
                    userDatabase.child("name").setValue(name);
                    userDatabase.child("phone").setValue(phone);
                    userDatabase.child("email").setValue(email);
                    userDatabase.child("prof_image")
                            .setValue(downloadUri.toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful())
                            {
                                pd.dismiss();
                                Toast.makeText(AccountActivity.this, "Profile Updated Successfully..", Toast.LENGTH_SHORT).show();

                               //startActivity(new Intent(AccountActivity.this,MainActivity.class));
                                finish();
                            }else {
                                pd.dismiss();
                                Toast.makeText(AccountActivity.this, "Error:"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                }else {
                    pd.dismiss();
                    Toast.makeText(AccountActivity.this, "Error: "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });




    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==GALLERY_REQUEST_CODE && resultCode==RESULT_OK)
        {
            imageUri=data.getData();
            profile_pic.setImageURI(imageUri);

        }else {
            Toast.makeText(this, "An Error Occured...", Toast.LENGTH_SHORT).show();
        }
    }
}
