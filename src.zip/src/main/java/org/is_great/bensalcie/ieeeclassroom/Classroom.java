package org.is_great.bensalcie.ieeeclassroom;

public class Classroom {

    private String title,date,content,file,lecturer,pic,youtube_link;

    public Classroom(String title, String date, String content, String file, String lecturer, String pic, String youtube_link) {
        this.title = title;
        this.date = date;
        this.content = content;
        this.file = file;
        this.lecturer = lecturer;
        this.pic = pic;
        this.youtube_link = youtube_link;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getLecturer() {
        return lecturer;
    }

    public void setLecturer(String lecturer) {
        this.lecturer = lecturer;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getYoutube_link() {
        return youtube_link;
    }

    public void setYoutube_link(String youtube_link) {
        this.youtube_link = youtube_link;
    }

    public Classroom(){

    }


}
