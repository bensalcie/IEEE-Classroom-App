package org.is_great.bensalcie.ieeeclassroom;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class NotificationFragment extends Fragment {
View v;
private RecyclerView notificationList;
private DatabaseReference mNotificationDatabase;


    public NotificationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v= inflater.inflate(R.layout.fragment_notification, container, false);
        mNotificationDatabase = FirebaseDatabase.getInstance().getReference().child("MadCNotifications");
        notificationList=v.findViewById(R.id.notification_list);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getActivity());
        //linearLayoutManager.setReverseLayout(true);
        notificationList.setLayoutManager(linearLayoutManager);



        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<AdminPosts,AdminPOstViewHolder> recyclerAdapter=new FirebaseRecyclerAdapter<AdminPosts, AdminPOstViewHolder>(AdminPosts.class,R.layout.notification_list_item,AdminPOstViewHolder.class,mNotificationDatabase) {
            @Override
            protected void populateViewHolder(AdminPOstViewHolder viewHolder, final AdminPosts model, int position) {
                viewHolder.setValues(model.getTitle(),model.getContent());
                viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String category="not";

                        startActivity(new Intent(getContext().getApplicationContext(),DetailsActivity.class).putExtra("category",category).putExtra("title",model.getTitle())
                        .putExtra("cont",model.getContent()));

                    }
                });
            }

        };
        notificationList.setAdapter(recyclerAdapter);
    }
    public static class AdminPOstViewHolder extends RecyclerView.ViewHolder{

View mView;

        public AdminPOstViewHolder(@NonNull View itemView) {
            super(itemView);
            mView=itemView;
        }

        public void setValues(String title,String content)
        {

            TextView tvContent,tvTitle=mView.findViewById(R.id.tvTitle);
            tvTitle.setText(title);

            tvContent=mView.findViewById(R.id.tvContent);
            tvContent.setText(content);
        }
    }
}
