package org.is_great.bensalcie.ieeeclassroom;


import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.PRINT_SERVICE;

public class HomeFragment extends Fragment {
    private static final int GALLERY_REQUEST_CODE = 23456;

    View v;
//private EditText etPost;
private FloatingActionButton btnPost;
private DatabaseReference mUsersDatabase,mAccountDatabase;
private RecyclerView postList;
private Dialog d;
private CircleImageView profile_image;
private TextView tvName;
private EditText etPost;
private Button btn_Post;
private ImageButton gallery_btn;
private ImageView post_image;
private FirebaseAuth mAuth;
private StorageReference mPhotosStorage;
private   Uri imageUri=null;
private ProgressBar progressBar;


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v= inflater.inflate(R.layout.fragment_home, container, false);
        mAuth=FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser()!=null) {
            String userId = mAuth.getCurrentUser().getUid();
            mUsersDatabase = FirebaseDatabase.getInstance().getReference().child("IEEEmadc_posts");
            mPhotosStorage = FirebaseStorage.getInstance().getReference().child("IEEEmadc_photos");
            // etPost=v.findViewById(R.id.etPost);
            mAccountDatabase = FirebaseDatabase.getInstance().getReference().child("IEEEmadc_accounts").child(userId);
        }
        btnPost=v.findViewById(R.id.btnPost);
        postList=v.findViewById(R.id.post_list);
        d=new Dialog(getContext());
        d.setContentView(R.layout.post_dialog);
        d.setTitle("Post Here");
        d.setCancelable(true);
        profile_image=d.findViewById(R.id.post_profile);
        tvName=d.findViewById(R.id.tvPost_Title);
        etPost=d.findViewById(R.id.et_post_post);
        btn_Post=d.findViewById(R.id.btn_post);
        gallery_btn=d.findViewById(R.id.iv_post_image);
        post_image=d.findViewById(R.id.postImage);
        progressBar=d.findViewById(R.id.progressBar3);


        gallery_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent=new Intent(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,GALLERY_REQUEST_CODE);
            }
        });
        btnPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


d.show();
setProfiles(mAccountDatabase);

            }
        });


       RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getContext());
       ((LinearLayoutManager) layoutManager).setReverseLayout(true);
        postList.setLayoutManager(layoutManager);
        /*btnPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String post=etPost.getText().toString().trim();
                if (!TextUtils.isEmpty(post))
                {
                    startPosting(post);

                }else {
                    Toast.makeText(getContext(), "Your Post is Empty...", Toast.LENGTH_SHORT).show();
                }
            }
        });*/
        return v;
    }

    private void setProfiles(final DatabaseReference mAccountDatabase) {
        mAccountDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot.hasChild("name")) {
                    String phone = dataSnapshot.child("phone").getValue().toString();
                    final String name=dataSnapshot.child("name").getValue().toString();
                    String email=dataSnapshot.child("email").getValue().toString();
                    final String prof_image=dataSnapshot.child("prof_image").getValue().toString();


                    //String image = dataSnapshot.child("image").getValue().toString();
                    tvName.setText("Posting as: \n"+name);
                    Glide.with(getContext()).load(prof_image).into(profile_image);
                   //Toast.makeText(getContext(), "Image:" + prof_image, Toast.LENGTH_SHORT).show();
                    btn_Post.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            progressBar.setVisibility(View.VISIBLE);
                            String post=etPost.getText().toString().trim();
                            if (!TextUtils.isEmpty(post))
                            {
                                if (imageUri!=null)
                                {
                                    startPosting(post,imageUri,name,prof_image);

                                }else {
                                    progressBar.setVisibility(View.INVISIBLE);
                                    Toast.makeText(getContext(), "Tap the attachment button to get some photo,Your post will be seen  by many...", Toast.LENGTH_SHORT).show();

                                }

                            }else {
                                progressBar.setVisibility(View.INVISIBLE);

                                Toast.makeText(getContext(), "Your post is empty...", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void startPosting(final String post, final Uri imageUri,final String name,final String _image) {
       // Toast.makeText(getContext(), "Posting", Toast.LENGTH_SHORT).show();

StorageReference photoPath=mPhotosStorage.child("IEEEmadc_post_images").child(imageUri.getLastPathSegment()+".jpg");
photoPath.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
    @Override
    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
        if (task.isSuccessful())
        {
            Uri downloadUri=task.getResult().getDownloadUrl();


            DatabaseReference newPost=mUsersDatabase.push();
            newPost.child("post").setValue(post);
            newPost.child("photo").setValue(downloadUri.toString());
            newPost.child("name").setValue(name);
            newPost.child("_image").setValue(_image).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful())
                    {

                        d.dismiss();
                        progressBar.setVisibility(View.GONE);
                        post_image.setImageURI(null);
                        etPost.setText("");

                    }else {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(getContext(), "Error:"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                    }
                }
            });


        }
        else {
            Toast.makeText(getContext(), "Error:"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
});



    }

    @Override
    public void onStart() {
        super.onStart();

        if (mAuth.getCurrentUser()!=null) {
            FirebaseRecyclerAdapter<Posts, postViewHolder> recyclerAdapter = new FirebaseRecyclerAdapter<Posts, postViewHolder>(Posts.class, R.layout.post_item, postViewHolder.class, mUsersDatabase) {
                @Override
                protected void populateViewHolder(postViewHolder viewHolder, final Posts model, int position) {

                    viewHolder.setPostContent(model.getPost());
                    viewHolder.setPhotoContent(getActivity(),model.getPhoto());
                    viewHolder.setPosterName(model.getName());
                    viewHolder.setPosterPhoto(getActivity(),model.get_image());
                    viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String category="fun";
                            startActivity(new Intent(getContext().getApplicationContext(),DetailsActivity.class)
                                    .putExtra("category",category).putExtra("content",
                                            model.getPost()).putExtra("photo",model.getPhoto()).putExtra("poster",model.getName()).putExtra("poster_image",model.get_image()));

                        }
                    });

                }

            };
            postList.setAdapter(recyclerAdapter);

        }
    }


    public static class postViewHolder extends RecyclerView.ViewHolder
    {
        View mView;

        public postViewHolder(@NonNull View itemView) {
            super(itemView);
            mView=itemView;
        }


        public void setPostContent(String content)
        {
            TextView tvContent=mView.findViewById(R.id.postContent);
            tvContent.setText(content);
        }
        public void setPhotoContent(Context ctx, String photo)
        {

            ImageView postImage=mView.findViewById(R.id.postPic);
            Glide.with(ctx).load(photo).into(postImage);
        }
        public void setPosterPhoto(Context ctx, String photo)
        {

            CircleImageView postImage=mView.findViewById(R.id.post_person_profile);
            Glide.with(ctx).load(photo).into(postImage);
        }
        public void setPosterName(String name)
        {

         TextView tvPosterName=mView.findViewById(R.id.postPersonName);
         tvPosterName.setText(name);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==GALLERY_REQUEST_CODE && resultCode==RESULT_OK)
        {
          imageUri=data.getData();

            post_image.setImageURI(imageUri);
            post_image.setVisibility(View.VISIBLE);

        }else {
            Toast.makeText(getContext(), "An Error occured...", Toast.LENGTH_SHORT).show();
        }
    }
}
